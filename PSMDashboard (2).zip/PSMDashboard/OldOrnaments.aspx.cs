﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PSMDashboard.AppCode;

namespace PSMDashboard
{
    public partial class OldOrnaments : System.Web.UI.Page
    {
        ClsPsmDash clscon = new ClsPsmDash();

        protected void Page_Load(object sender, EventArgs e)
        {
            BindGrid();
        }

        private void BindMainGrid()
        {
            DataTable branchData = GetBranchSummaryData();
            MainGrid.DataSource = branchData;
            MainGrid.DataBind();
        }

        protected void MainGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                // Retrieve the branchID from CommandArgument
                string branchID = e.CommandArgument.ToString();

                // Store the branchID in ViewState for later use
                ViewState["SelectedBranchID"] = branchID;

                // Bind the detail grid with data
                BindDetailGrid(branchID);


                // Use the branch ID to display details in the DetailPanel

                DetailPanel.Visible = true;
                // Show the modal popup
                ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "document.getElementById('DetailPanel').style.display='block';", true);
            }
        }


        private void BindDetailGrid(string branchID)
        {
            // Call the BindDetailData method to get the product data for the selected branch and metal
            DataSet detailData = clscon.BindOldDetailData(branchID, "Gold");

            // Check if the dataset contains any tables and rows
            if (detailData != null && detailData.Tables.Count > 0 && detailData.Tables[0].Rows.Count > 0)
            {
                // Retrieve the branch name from the first row of the dataset
                string branchName = detailData.Tables[0].Rows[0]["location"].ToString();

                // Set the label text to include the branch name
                BranchLabel.Text = "Details for " + branchName + " Branch: ";

                // Bind the data to the DetailGrid
                DetailGrid.DataSource = detailData;
                DetailGrid.DataBind();
            }
            else
            {
                // Handle the case when there is no data returned
                BranchLabel.Text = "No details available for the selected branch.";
                DetailGrid.DataSource = null;
                DetailGrid.DataBind();
            }
        }


        // Fetch branch summary data from SQL Server with a specific location
        private DataTable GetBranchSummaryData(string location = null)
        {
            try
            {
                // If location is null, it defaults to all locations (or adjust as needed)
                DataSet ds = clscon.BindOldOrnamnetsData(location ?? "ALL"); // Assuming "ALL" fetches all branches if needed.

                if (ds != null && ds.Tables.Count > 0)
                {
                    return ds.Tables[0];
                }
                else
                {
                    return new DataTable();
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching branch summary data", ex);
            }
        }


        private void BindGrid()
        {
            DataSet ds = clscon.BindOldOrnamnetsData(null); // Pass null or an empty string if location is not needed for filtering

            if (ds != null && ds.Tables.Count > 0)
            {
                MainGrid.DataSource = ds.Tables[0];
                MainGrid.DataBind();

                // Variables to hold the total weight for all branches
                decimal totalGold = 0;
                decimal totalSilver = 0;
                decimal totalDiamond = 0;
                decimal totalPlatinum = 0;
                decimal totalMRP = 0;

                // Calculate the total weights across all branches
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    totalGold += Convert.ToDecimal(row["GoldNetwt"]);
                    totalSilver += Convert.ToDecimal(row["SilverNetwt"]);
                    totalDiamond += Convert.ToDecimal(row["DiaNetwt"]);
                    totalPlatinum += Convert.ToDecimal(row["platNetwt"]);
                    totalMRP += Convert.ToDecimal(row["MRPNetwt"]);
                }

                // Set footer row values
                GridViewRow footerRow = MainGrid.FooterRow;
                if (footerRow != null)
                {
                    footerRow.Cells[0].Text = "Total"; // Assuming the first column is for labels
                    footerRow.Cells[1].Text = totalGold.ToString("N2"); // Format as needed
                    footerRow.Cells[2].Text = totalSilver.ToString("N2");
                    footerRow.Cells[3].Text = totalDiamond.ToString("N2");
                    footerRow.Cells[4].Text = totalPlatinum.ToString("N2");
                    footerRow.Cells[5].Text = totalMRP.ToString("N2");


                    //  footerRow.Style = FontSize("12px;");
                    footerRow.BackColor = System.Drawing.Color.FromArgb(255, 134, 13);
                    footerRow.ForeColor = System.Drawing.Color.White; // Optional: Change text color
                    foreach (TableCell cell in footerRow.Cells)
                    {
                        cell.HorizontalAlign = HorizontalAlign.Center;

                    }

                }
            }
        }


        // details table header


        // Fetch detailed product data for a branch from SQL Server
        //private DataTable GetBranchDetailData(string branchID)
        //{
        //    try
        //    {
        //        // Use the branchID to fetch detailed data for the specific branch
        //        DataSet ds = clscon.BindDetailData(branchID, "Gold");

        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            string branchName = ds.Tables[0].Rows[0]["location"].ToString();
        //            BranchLabel.Text = branchName;
        //            return ds.Tables[0];
        //        }
        //        else
        //        {
        //            return new DataTable();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error fetching branch detail data", ex);
        //    }
        //}

        //protected void goldBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable goldData = clscon.BindDetailData(branchID, "Gold").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = goldData;
        //    DetailGrid.DataBind();                                                                     // Bind the goldData to your grid
        //}

        //protected void SilverBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable silverData = clscon.BindDetailData(branchID, "Silver").Tables[0]; // Pass "Silver" as the metal name
        //    DetailGrid.DataSource = silverData;
        //    DetailGrid.DataBind();                                                                    // Bind the silverData to your grid
        //}

        //protected void DiamondBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable diamondData = clscon.BindDetailData(branchID, "Diamond").Tables[0]; // Pass "Diamond" as the metal name
        //    DetailGrid.DataSource = diamondData;
        //    DetailGrid.DataBind();                                                                                // Bind the diamondData to your grid
        //}

        //// Helper method to get the branch ID (you need to implement this method)
        //private string GetBranchID()
        //{
        //    // Check if the ViewState has the branchID
        //    if (ViewState["SelectedBranchID"] != null)
        //    {
        //        return ViewState["SelectedBranchID"].ToString();
        //    }
        //    else
        //    {
        //        throw new Exception("Branch ID not set or available");
        //    }
        //}

        //protected void PlatinumBTN_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable PlatinumData = clscon.BindDetailData(branchID, "Platinum").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = PlatinumData;
        //    DetailGrid.DataBind();
        //}

        //protected void RateItemBtn_Click1(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable rateData = clscon.BindDetailData(branchID, "MRP").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = rateData;
        //    DetailGrid.DataBind();
        //}

    }
}