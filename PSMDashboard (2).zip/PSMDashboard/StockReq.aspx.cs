﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.Configuration;
using System.Web.UI.WebControls;

namespace PSMDashboard
{
    public partial class StockReq : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                productDetailsList.Clear();  // Clear the list on first load
                ProductGridView.DataSource = null;  // Clear any previous data
                ProductGridView.DataBind();  // Rebind to show an empty grid
            }

        }

      
        // List to hold the added products locally
        private static List<ProductDetail> productDetailsList = new List<ProductDetail>();

        // Class to represent a product detail


        [System.Web.Services.WebMethod]
        public static ProductDetails GetProductDetails(string productName)
        {
            ProductDetails details = new ProductDetails();
            string connectionString = ConfigurationManager.ConnectionStrings["conSTR"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("SELECT Size, Weight,Metal FROM ProductMaster WHERE Product = @Product", connection);
                command.Parameters.AddWithValue("@Product", productName);
                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    details.Size = reader["Size"].ToString();
                    details.Weight = reader["Weight"].ToString();
                    details.metal = reader["Metal"].ToString();
                }
            }

            return details;
        }

        public class ProductDetails
        {
            public string Size { get; set; }
            public string Weight { get; set; }
            public string metal { get; set; }
        }

        public class ProductDetail
        {
            public string MetalType { get; set; }
            public string ProductName { get; set; }
            public decimal Size { get; set; }
            public decimal Weight { get; set; }
            public int Quantity { get; set; }
            public decimal TotalWeight { get; set; }
        }

        // Add button click event
        protected void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                // Retrieve the values from the input controls
                //string metalType = hiddenMetalType.Text;
                string productName = txtProductName.Text;

                // Ensure the product name is entered
                if (string.IsNullOrWhiteSpace(productName))
                {
                    lblError.Text = "Please enter a product name.";
                    return;
                }

                // Get product details from the server
                ProductDetails productDetails = GetProductDetails(productName);

                // Check if product details are available
                if (productDetails == null || string.IsNullOrWhiteSpace(productDetails.Size) || string.IsNullOrWhiteSpace(productDetails.Weight))
                {
                    lblError.Text = "Product details (Size and Weight) not found.";
                    return;
                }

                // Retrieve quantity input and validate it
                if (string.IsNullOrWhiteSpace(txtQuantity.Text))
                {
                    lblError.Text = "Please enter a quantity.";
                    return;
                }

                if (!int.TryParse(txtQuantity.Text, out int quantity))
                {
                    lblError.Text = "Invalid input for Quantity. Please enter a valid integer.";
                    return;
                }

                // Safely parse size and weight as decimals
                decimal size = Convert.ToDecimal(productDetails.Size);
                decimal weight = Convert.ToDecimal(productDetails.Weight);
                string metalType = Convert.ToString(productDetails.metal);

                // Calculate total weight
                decimal totalWeight = weight * quantity;

                // Add the new product detail to the list
                productDetailsList.Add(new ProductDetail
                {
                    MetalType = metalType,
                    ProductName = productName,
                    Size = size,
                    Weight = weight,
                    Quantity = quantity,
                    TotalWeight = totalWeight
                });

                // Bind the updated list to the GridView
                ProductGridView.DataSource = productDetailsList;
                ProductGridView.DataBind();

                // Clear any error messages and reset inputs
                lblError.Text = string.Empty;
                txtProductName.Text = string.Empty;
                txtQuantity.Text = string.Empty;
            }
            catch (Exception ex)
            {
                // Handle any unexpected errors
                lblError.Text = "An error occurred: " + ex.Message;
            }
        }



        // Save button click event
        protected void btnSave_Click(object sender, EventArgs e)
        {
            string connectionString = WebConfigurationManager.ConnectionStrings["conSTR"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                foreach (var product in productDetailsList)
                {
                    string query = "INSERT INTO StockReq_DB (Metal, Product, Size, Weight, ReqPcs, TotalWeight) " +
                                   "VALUES (@MetalType, @Product, @Size, @Weight, @ReqPcs, @TotalWeight)";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MetalType", product.MetalType);
                        command.Parameters.AddWithValue("@Product", product.ProductName);
                        command.Parameters.AddWithValue("@Size", product.Size);
                        command.Parameters.AddWithValue("@Weight", product.Weight);
                        command.Parameters.AddWithValue("@ReqPcs", product.Quantity);
                        command.Parameters.AddWithValue("@TotalWeight", product.TotalWeight);

                        command.ExecuteNonQuery();
                    }
                }
                connection.Close();
            }

            productDetailsList.Clear();
            ProductGridView.DataSource = null;
            ProductGridView.DataBind();

            lblMessage.Text = "Data saved successfully!";
        }

        // Metal button click event to set the metal type
  

        // Method for AutoCompleteExtender
        [System.Web.Services.WebMethod]
        public static List<string> GetProductNames(string prefixText)
        {
            List<string> productNames = new List<string>();
            string connectionString = WebConfigurationManager.ConnectionStrings["conSTR"].ConnectionString;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Product FROM ProductMaster WHERE Product LIKE ' %' + @prefixText + '%' ";
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@prefixText", prefixText);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        productNames.Add(reader["Product"].ToString());
                    }
                    connection.Close();
                }
            }
            return productNames;
        }
    }
}
