﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PSMDashboard.AppCode;

namespace PSMDashboard
{
    public partial class OrderBooking : System.Web.UI.Page
    {
        ClsPsmDash clscon = new ClsPsmDash();

        protected void Page_Load(object sender, EventArgs e)
        {
            string location = null; // Initialize location to null
            DateTime? fromDate = null;
            DateTime? toDate = null;

            // Set the current date as the initial value for TextBox1 (fromDate) and TextBox2 (toDate) if not already set
            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            // Bind the grid using the parsed or default values
            BindGrid(location, fromDate, toDate);
        }

        private void BindMainGrid()
        {
            DataTable branchData = GetBranchSummaryData();
            MainGrid.DataSource = branchData;
            MainGrid.DataBind();
        }

        protected void MainGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                // Retrieve the branchID from CommandArgument
                string branchID = e.CommandArgument.ToString();

                // Store the branchID in ViewState for later use
                ViewState["SelectedBranchID"] = branchID;

                // Bind the detail grid with data
                BindDetailGrid(branchID);


                // Use the branch ID to display details in the DetailPanel

                DetailPanel.Visible = true;
                // Show the modal popup
                ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "document.getElementById('DetailPanel').style.display='block';", true);
            }
        }


        private void BindDetailGrid(string branchID)
        {
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }
            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }
            // Call the BindOrderDetailData method to get the product data for the selected branch and metal
            DataSet detailData = clscon.BindOrderDetailData(branchID, "Gold", fromDate, toDate);

            // Check if the dataset contains any tables and rows
            if (detailData != null && detailData.Tables.Count > 0 && detailData.Tables[0].Rows.Count > 0)
            {
                // Retrieve the branch name from the first row of the dataset
                string branchName = detailData.Tables[0].Rows[0]["Branch"].ToString();

                // Set the label text to include the branch name
                BranchLabel.Text = "Details for " + branchName + " Branch: ";

                // Bind the data to the DetailGrid
                DetailGrid.DataSource = detailData;
                DetailGrid.DataBind();
            }
            else
            {
                // Handle the case when there is no data returned
                BranchLabel.Text = "No details available for the selected branch.";
                DetailGrid.DataSource = null;
                DetailGrid.DataBind();
            }
        }


        // Fetch branch summary data from SQL Server with a specific location
        private DataTable GetBranchSummaryData(string location = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            try
            {
                // If location is null, it defaults to all locations (or adjust as needed)
                DataSet ds = clscon.BindOrderSummaryData(location ?? "ALL", fromDate, toDate); // Assuming "ALL" fetches all branches if needed.

                if (ds != null && ds.Tables.Count > 0)
                {
                    return ds.Tables[0];
                }
                else
                {
                    return new DataTable();
                }

            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching branch summary data", ex);
            }
        }


     













        private void BindGrid(string location, DateTime? fromDate = null, DateTime? toDate = null)
        {

         

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }
            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            location = "ALL";  // Replace with actual location value

            // Fetch data with location and date filters
            DataSet ds = clscon.BindOrderSummaryData(location, fromDate, toDate);

            if (ds != null && ds.Tables.Count > 0)
            {
                MainGrid.DataSource = ds.Tables[0];
                MainGrid.DataBind();

                // Variables to hold the total weight for all branches
                decimal totalGold = 0;
                decimal totalSilver = 0;
                decimal totalDiamond = 0;
                decimal totalPlatinum = 0;
                decimal totalMRP = 0;

                // Calculate the total weights across all branches
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    totalGold += Convert.ToDecimal(row["GoldNetwt"]);
                    totalSilver += Convert.ToDecimal(row["SilverNetwt"]);

                }

                // Set footer row values
                GridViewRow footerRow = MainGrid.FooterRow;
                if (footerRow != null)
                {
                    footerRow.Cells[0].Text = "Total"; // Assuming the first column is for labels
                    footerRow.Cells[1].Text = totalGold.ToString("N2"); // Format as needed
                    footerRow.Cells[2].Text = totalSilver.ToString("N2");
                    footerRow.Cells[3].Text = totalDiamond.ToString("N2");
                    footerRow.Cells[4].Text = totalPlatinum.ToString("N2");
                    footerRow.Cells[5].Text = totalMRP.ToString("N2");


                    //  footerRow.Style = FontSize("12px;");
                    footerRow.BackColor = System.Drawing.Color.FromArgb(255, 134, 13);
                    footerRow.ForeColor = System.Drawing.Color.White; // Optional: Change text color
                    foreach (TableCell cell in footerRow.Cells)
                    {
                        cell.HorizontalAlign = HorizontalAlign.Center;
                        if (cell.Text == totalSilver.ToString("N2") || cell.Text == totalGold.ToString("N2") || cell.Text == "Total" || cell.Text == totalDiamond.ToString("N2") || cell.Text == totalPlatinum.ToString("N2")|| cell.Text==totalMRP.ToString("N2"))
                        {
                            // Setting font weight and font family for the total values
                            cell.Font.Bold = true; // Make the text bold
                            cell.Font.Name = "Arial"; // Change the font (can change to any font you prefer)
                            cell.Font.Size = 16; // Set font size to 16px
                        }

                    }

                }
            }
        }


        // details table header


        // Fetch detailed product data for a branch from SQL Server
        private DataTable GetBranchDetailData(string branchID, DateTime? fromDate = null, DateTime? toDate = null)
        {
            try
            {
                // Use the branchID to fetch detailed data for the specific branch
                DataSet ds = clscon.BindOrderDetailData(branchID, "Gold", fromDate, toDate);

                if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string branchName = ds.Tables[0].Rows[0]["location"].ToString();
                    BranchLabel.Text = branchName;
                    return ds.Tables[0];
                }
                else
                {
                    return new DataTable();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching branch detail data", ex);
            }
        }

        protected void goldBtn_Click(object sender, EventArgs e)
        {
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }
            string branchID = GetBranchID(); // Replace with your logic to get the branch ID
            DataTable goldData = clscon.BindOrderDetailData(branchID, "Gold", fromDate, toDate).Tables[0]; // Pass "Gold" as the metal name
            DetailGrid.DataSource = goldData;
            DetailGrid.DataBind();                                                                     // Bind the goldData to your grid
        }

        protected void SilverBtn_Click(object sender, EventArgs e)
        {


            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }
            string branchID = GetBranchID(); // Replace with your logic to get the branch ID
            DataTable silverData = clscon.BindOrderDetailData(branchID, "Silver", fromDate, toDate).Tables[0]; // Pass "Silver" as the metal name
            DetailGrid.DataSource = silverData;
            DetailGrid.DataBind();                                                                    // Bind the silverData to your grid
        }

        protected void DiamondBtn_Click(object sender, EventArgs e)
        {
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            string branchID = GetBranchID(); // Replace with your logic to get the branch ID
            DataTable diamondData = clscon.BindOrderDetailData(branchID, "Diamond", fromDate, toDate).Tables[0]; // Pass "Diamond" as the metal name
            DetailGrid.DataSource = diamondData;
            DetailGrid.DataBind();                                                                                // Bind the diamondData to your grid
        }

        // Helper method to get the branch ID (you need to implement this method)
        private string GetBranchID()
        {
            // Check if the ViewState has the branchID
            if (ViewState["SelectedBranchID"] != null)
            {
                return ViewState["SelectedBranchID"].ToString();
            }
            else
            {
                throw new Exception("Branch ID not set or available");
            }
        }

        protected void PlatinumBTN_Click(object sender, EventArgs e)
        {
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            string branchID = GetBranchID(); // Replace with your logic to get the branch ID
            DataTable PlatinumData = clscon.BindOrderDetailData(branchID, "Platinum", fromDate, toDate).Tables[0]; // Pass "Gold" as the metal name
            DetailGrid.DataSource = PlatinumData;
            DetailGrid.DataBind();
        }



        protected void RateItemBtn_Click1(object sender, EventArgs e)
        {
            DateTime? fromDate = null;
            DateTime? toDate = null;

            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            string branchID = GetBranchID(); // Replace with your logic to get the branch ID
            DataTable rateData = clscon.BindOrderDetailData(branchID, "MRP", fromDate, toDate).Tables[0]; // Pass "Gold" as the metal name
            DetailGrid.DataSource = rateData;
            DetailGrid.DataBind();
        }





        //private void BindGrid()
        //{
        //    DataSet ds = clscon.BindOrderSummaryData(null); // Pass null or an empty string if location is not needed for filtering

        //    if (ds != null && ds.Tables.Count > 0)
        //    {
        //        MainGrid.DataSource = ds.Tables[0];
        //        MainGrid.DataBind();

        //        // Variables to hold the total weight for all branches
        //        int totalGoldCount = 0;
        //        int totalSilverCount = 0;
        //        int totalDiamondCount = 0;
        //        int totalPlatCount = 0;
        //        int totalRateCount = 0;
        //        int totalGoldValues = 0;
        //        int totalSilverValues = 0;
        //        int totalDiamondValues = 0;
        //        int totalPlatValues = 0;
        //        int totalRateValues = 0;

        //        // Calculate the total weights across all branches
        //        foreach (DataRow row in ds.Tables[0].Rows)
        //        {
        //    //        --Separate counts for each metal type

        //    //COUNT(CASE WHEN Metal = 'Diamond' THEN 1 ELSE NULL END) AS DiamondOrderCount,
        //    //COUNT(CASE WHEN Metal = 'Gold' THEN 1 ELSE NULL END) AS GoldOrderCount,
        //    //COUNT(CASE WHEN Metal = 'Silver' THEN 1 ELSE NULL END) AS SilverOrderCount,
        //    //COUNT(CASE WHEN Metal = 'Platinum' THEN 1 ELSE NULL END) AS PlatinumOrderCount,
        //    //COUNT(CASE WHEN Metal = 'MRP' THEN 1 ELSE NULL END) AS MRPOrderCount,

        //    //--Separate net weight values for each metal type

        //    //SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetWt,
        //    //SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetWt,
        //    //SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetWt,
        //    //SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS PlatinumNetWt,
        //    //SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetWt

        //                    totalGoldCount += Convert.ToInt32(row["GoldOrderCount"]);
        //            totalSilverCount += Convert.ToInt32(row["SilverOrderCount"]);
        //            totalDiamondCount += Convert.ToInt32(row["DiamondOrderCount"]);
        //            totalPlatCount += Convert.ToInt32(row["PlatinumOrderCount"]);
        //            totalRateCount += Convert.ToInt32(row["MRPOrderCount"]);
        //            totalGoldValues += Convert.ToInt32(row["TotalSwarnaValue"]);
        //            totalSilverValues += Convert.ToInt32(row["TotalSwarnaValue"]);
        //            totalPlatValues += Convert.ToInt32(row["TotalSwarnaValue"]);
        //            totalRateValues += Convert.ToInt32(row["TotalSwarnaValue"]);
        //        }

        //        // Set footer row values
        //        GridViewRow footerRow = MainGrid.FooterRow;
        //        if (footerRow != null)
        //        {
        //            footerRow.Cells[0].Text = "Total"; // Assuming the first column is for labels
        //            footerRow.Cells[1].Text = FormatAmount(totalGold); // Format the totalGold
        //            footerRow.Cells[2].Text = FormatAmount(totalSilver); // Format the totalSilver
        //            footerRow.Cells[3].Text = totalSwrnacount.ToString("N0"); // Assuming totalSwrnacount is a simple integer
        //            footerRow.Cells[4].Text = FormatAmount(totalswrnavalue); // Format the totalswrnavalue

        //            //  footerRow.Style = FontSize("12px;");
        //            footerRow.BackColor = System.Drawing.Color.FromArgb(255, 134, 13);
        //            footerRow.ForeColor = System.Drawing.Color.White; // Optional: Change text color

        //            foreach (TableCell cell in footerRow.Cells)
        //            {
        //                cell.HorizontalAlign = HorizontalAlign.Center;
        //                if (cell.Text == FormatAmount(totalGold) || cell.Text == FormatAmount(totalSilver) || cell.Text == "Total" || cell.Text == FormatAmount(totalswrnavalue) || cell.Text == FormatAmount(totalSwrnacount))
        //                {
        //                    // Setting font weight and font family for the total values
        //                    cell.Font.Bold = true; // Make the text bold
        //                    cell.Font.Name = "Arial"; // Change the font (can change to any font you prefer)
        //                    cell.Font.Size = 16; // Set font size to 16px
        //                }
        //            }
        //        }
        //    }
        //}

        //// Helper method to format amounts into Lakhs (L) or Crores (Cr)
        //private string FormatAmount(int amount)
        //{
        //    if (amount >= 10000000)
        //    {
        //        // If the amount is greater than or equal to 1 Crore (10,000,000)
        //        return (amount / 10000000.0).ToString("0.##") + " Cr"; // Format in Crores
        //    }
        //    else if (amount >= 100000)
        //    {
        //        // If the amount is greater than or equal to 1 Lakh (100,000)
        //        return (amount / 100000.0).ToString("0.##") + " L"; // Format in Lakhs
        //    }
        //    else
        //    {
        //        // For amounts less than 1 Lakh
        //        return amount.ToString("N0"); // No suffix, just the number with thousand separators
        //    }
        //}
    }
}