﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PSMDashboard
{
    public partial class MainHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (!IsPostBack)
            {
                var apps = new List<AppDetails>
            {
                new AppDetails { AppName = "Sales", AppLogo = "fa-solid fa-book-open-reader", AppUrl = "CurrentSales.aspx" },
               // new AppDetails { AppName = "Sales", AppLogo = "fa-solid fa-user-tie", AppUrl ="Submenu.aspx?app=HR" },
                new AppDetails { AppName = "Chit Enrollment", AppLogo = "fa-solid fa-chart-line", AppUrl = "Chits.aspx" },
                new AppDetails { AppName = "Chit Collection", AppLogo = "fa-solid fa-star", AppUrl = "ChitEnroll.aspx" },
              //  new AppDetails { AppName = "Old Ornaments", AppLogo = "fa-regular fa-hand-point-up", AppUrl = "OldOrnaments.aspx" },
              //new AppDetails { AppName = "Advance",AppLogo = "fa-solid fa-person-walking-arrow-right", AppUrl = "Submenu.aspx?app=Leads" },
                new AppDetails { AppName = "Order",AppLogo = "fa-solid fa-person-circle-check", AppUrl = "OrderBooking.aspx?" },
                new AppDetails { AppName = "Repair", AppLogo = "fa-solid fa-percent", AppUrl = "RepairBooking.aspx" },
                new AppDetails { AppName = "Walkin ", AppLogo = "fa-solid fa-address-card", AppUrl = "WalkIN.aspx" },
                new AppDetails { AppName = "Non Conversion", AppLogo = "fa-solid fa-address-card", AppUrl = "NOC.aspx" },
                new AppDetails { AppName = "Stock Requiremnt", AppLogo = "fa-brands fa-buffer", AppUrl = "StockReq.aspx" },
                   new AppDetails { AppName = "AdminView", AppLogo = "fa-brands fa-buffer", AppUrl = "AdminView.aspx" },
                      new AppDetails { AppName = "Employee Performance", AppLogo = "fa-brands fa-buffer", AppUrl = "Employee.aspx" },
               // new AppDetails { AppName = "Re-Order List", AppLogo = "fa-solid fa-people-roof", AppUrl = "Submenu.aspx" },
               // new AppDetails { AppName = "Contact", AppLogo = "fa-solid fa-id-badge", AppUrl = "contacts.aspx" },
              //  new AppDetails { AppName = "Circular", AppLogo = "fa-solid fa-bullhorn", AppUrl = "circularview.aspx" },
               // new AppDetails { AppName = "About AVRSM", AppLogo = "fas fa-calendar-alt", AppUrl = "Submenu.aspx?app=Abouts" },
               // new AppDetails { AppName = "Feedback & Suggestion",AppLogo = "fa-solid fa-comments", AppUrl = "feedbackform.aspx" }
                // Add more apps as needed
            };

                rptApps.DataSource = apps;
                rptApps.DataBind();
            }
        }
    }

    public class AppDetails
    {
        public string AppName { get; set; }
        public string AppLogo { get; set; }  // This will store the Font Awesome class string
        public string AppUrl { get; set; }
    }
}