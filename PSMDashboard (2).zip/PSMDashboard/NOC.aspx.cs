﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PSMDashboard.AppCode;

namespace PSMDashboard
{
    public partial class NOC : System.Web.UI.Page
    {

        ClsPsmDash clsCon = new ClsPsmDash();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ShowAlertWithRedirect(string message, string redirectUrl)
        {
            string script = $"alert('{message}'); window.location='{redirectUrl}';";
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", script, true);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            String cusName = txtName.Text;
            string cusPhone = txtPhone.Text;

            try
            {

                DataSet dsNOC = new DataSet();
                dsNOC = clsCon.StockNoc(cusName, cusPhone);


                ShowAlertWithRedirect("Data added successfully!", "NOC.aspx");

            }
            catch (Exception ex)
            {

                Response.Write(ex.Message.ToString());
            }
        }
    }
}