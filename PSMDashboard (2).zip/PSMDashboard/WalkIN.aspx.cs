﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PSMDashboard.AppCode;

namespace PSMDashboard
{
    public partial class WalkIN : System.Web.UI.Page
    {
        protected void ShowAlertWithRedirect(string message, string redirectUrl)
        {
            string script = $"alert('{message}'); window.location='{redirectUrl}';";
            ScriptManager.RegisterStartupScript(this, GetType(), "showalert", script, true);
        }

        ClsPsmDash clsCon = new ClsPsmDash();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindProduct();
                BindMetal();
            }
        }

        private void BindProduct()
        {
            DataSet ds = clsCon.WalkIN(); // Call the modified method

            if (ds.Tables[0].Rows.Count > 0)
            {
                ProductName.DataSource = ds;
                ProductName.DataTextField = "ProductName"; // Display text
                ProductName.DataValueField = "ProductID"; // Value
                ProductName.DataBind();
            }

            // Optionally, add a default "Select" item at the top
            ProductName.Items.Insert(0, new ListItem("--Select --", "0"));
        }

        private void BindMetal()
        {
            DataSet ds = clsCon.WalkIN(); // Call the modified method

            if (ds.Tables[0].Rows.Count > 0)
            {
                Metal.DataSource = ds;
                Metal.DataTextField = "Metal"; // Display text
                Metal.DataValueField = "MetalID"; // Value
                Metal.DataBind();
            }

            // Optionally, add a default "Select" item at the top
            Metal.Items.Insert(0, new ListItem("--Select --", "0"));
        }

        protected void WalkInbtn_Click(object sender, EventArgs e)
        {

            string pro = ProductName.SelectedItem.Text;
            int proID = Convert.ToInt32(ProductName.SelectedValue);

            string metal = Metal.SelectedItem.Text;
            int metalID = Convert.ToInt32(Metal.SelectedValue);

            int count = Convert.ToInt32(CusCount.Text);

            try
            {

                DataSet dsStockReq = new DataSet();
                dsStockReq = clsCon.WalkReq(proID, pro, metal, metalID, count);


                ShowAlertWithRedirect("Record updated successfully!", "WalkIN.aspx");
                //Response.Redirect("StockReq.aspx");

            }

            catch (Exception ex)
            {

                Response.Write(ex.Message.ToString());
            }


        }
    }
}