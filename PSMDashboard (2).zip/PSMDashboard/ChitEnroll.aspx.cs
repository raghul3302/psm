﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using PSMDashboard.AppCode;

namespace PSMDashboard
{
    public partial class ChitEnroll : System.Web.UI.Page
    {
        ClsPsmDash clscon = new ClsPsmDash();

        protected void Page_Load(object sender, EventArgs e)
        {
            string location = null; // Initialize location to null
            DateTime? fromDate = null;
            DateTime? toDate = null;

            // Set the current date as the initial value for TextBox1 (fromDate) and TextBox2 (toDate) if not already set
            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            // Bind the grid using the parsed or default values
            BindGrid(location, fromDate, toDate);
        }

        private void BindMainGrid()
        {
            DataTable branchData = GetBranchSummaryData();
            MainGrid.DataSource = branchData;
            MainGrid.DataBind();
        }

        protected void MainGrid_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "ShowDetails")
            {
                // Retrieve the branchID from CommandArgument
                string branchID = e.CommandArgument.ToString();

                // Store the branchID in ViewState for later use
                ViewState["SelectedBranchID"] = branchID;

                // Bind the detail grid with data
                //BindDetailGrid(branchID);


                // Use the branch ID to display details in the DetailPanel

                DetailPanel.Visible = true;
                // Show the modal popup
                ScriptManager.RegisterStartupScript(this, GetType(), "showModal", "document.getElementById('DetailPanel').style.display='block';", true);
            }
        }

        protected void MainGrid_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
            {
                // Create a new GridViewRow for the master headers
                GridViewRow masterHeaderRow = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);

                // Create the header cell for "Branch"
                TableCell branchHeaderCell = new TableCell
                {
                    Text = "", // Text for the "Branch" column
                    RowSpan = 1, // Span the entire height to align with other headers
                    CssClass = "branch-header-text" // Custom CSS class for styling
                };
                masterHeaderRow.Cells.Add(branchHeaderCell);

                // Create the header cell for "Scheme 01"
                TableCell scheme1HeaderCell = new TableCell
                {
                    Text = "New Swarna Subiksha", // Text for Scheme 01 header
                    ColumnSpan = 2, // Span across the next two columns
                    CssClass = "master-header-text" // Custom CSS class for styling
                };
                masterHeaderRow.Cells.Add(scheme1HeaderCell);

                // Create the header cell for "Scheme 02"
                TableCell scheme2HeaderCell = new TableCell
                {
                    Text = "Swarna Subiksha", // Text for Scheme 02 header
                    ColumnSpan = 2, // Span across the next two columns
                    CssClass = "master-header-text" // Custom CSS class for styling
                };
                masterHeaderRow.Cells.Add(scheme2HeaderCell);

                // Add the master header row to the GridView
                MainGrid.Controls[0].Controls.AddAt(0, masterHeaderRow);
            }
        }



     
        private DataTable GetBranchSummaryData(string location = null, DateTime? fromDate = null, DateTime? toDate = null)
        {
            try
            {
                // Use "ALL" if no specific location is provided
                DataSet ds = clscon.BindChitDetailsda(location ?? "ALL", fromDate, toDate);

                if (ds != null && ds.Tables.Count > 0)
                {
                    return ds.Tables[0];
                }
                else
                {
                    return new DataTable();
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error fetching branch summary data", ex);
            }
        }

        private void BindGrid(string location, DateTime? fromDate = null, DateTime? toDate = null)
        {
            // Parse the date values from the TextBoxes, if provided
         
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }
            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            // Fetch the data with date filters
            DataSet ds = clscon.BindChitDetailsda(location, fromDate, toDate);

            if (ds != null && ds.Tables.Count > 0)
            {
                MainGrid.DataSource = ds.Tables[0];
                MainGrid.DataBind();
            }
        }
        protected void FilterButton_Click(object sender, EventArgs e)
        {
            string location = null; // Initialize location to null
            DateTime? fromDate = null;
            DateTime? toDate = null;

            // Set the current date as the initial value for TextBox1 (fromDate) and TextBox2 (toDate) if not already set
            if (string.IsNullOrEmpty(TextBox1.Text))
            {
                fromDate = DateTime.Now.Date;
                TextBox1.Text = fromDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            if (string.IsNullOrEmpty(TextBox2.Text))
            {
                toDate = DateTime.Now.Date;
                TextBox2.Text = toDate.Value.ToString("yyyy-MM-dd"); // Format as needed
            }

            // Parse the date values from the TextBoxes, if provided
            if (DateTime.TryParse(TextBox1.Text, out DateTime parsedFromDate))
            {
                fromDate = parsedFromDate;
            }

            if (DateTime.TryParse(TextBox2.Text, out DateTime parsedToDate))
            {
                toDate = parsedToDate;
            }

            // Bind the grid using the parsed or default values
            BindGrid(location, fromDate, toDate);
        }
        protected void MainGrid_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                for (int i = 1; i < e.Row.Cells.Count; i++) // Assuming the first column is not numeric
                {
                    if (decimal.TryParse(e.Row.Cells[i].Text, out decimal value))
                    {
                        e.Row.Cells[i].Text = FormatAmount((int)value);
                    }
                }
            }

            // Footer row totals
            if (e.Row.RowType == DataControlRowType.Footer)
            {
                // Example for calculating totals (adjust column indices as needed)
                int totalGold = 0;
                int totalSilver = 0;
                int totalSwrnaCount = 0;
                int totalSwrnaValue = 0;

                foreach (DataRow row in ((DataTable)MainGrid.DataSource).Rows)
                {
                    totalGold += Convert.ToInt32(row["NewSwarnaSchemeCount"]);
                    totalSilver += Convert.ToInt32(row["TotalNewSwarnaValue"]);
                    totalSwrnaCount += Convert.ToInt32(row["SwarnaSchemeCount"]);
                    totalSwrnaValue += Convert.ToInt32(row["TotalSwarnaValue"]);
                }

                e.Row.Cells[0].Text = "Total";
                e.Row.Cells[1].Text = FormatAmount(totalGold);
                e.Row.Cells[2].Text = FormatAmount(totalSilver);
                e.Row.Cells[3].Text = totalSwrnaCount.ToString("N0");
                e.Row.Cells[4].Text = FormatAmount(totalSwrnaValue);

                e.Row.BackColor = System.Drawing.Color.FromArgb(255, 134, 13);
                e.Row.ForeColor = System.Drawing.Color.White;

                foreach (TableCell cell in e.Row.Cells)
                {
                    cell.HorizontalAlign = HorizontalAlign.Center;
                    cell.Font.Bold = true;
                    cell.Font.Name = "Arial";
                    cell.Font.Size = 16;
                 
                }
            }
        }
        // Helper method to format amounts into Lakhs (L) or Crores (Cr)
        private string FormatAmount(int amount)
        {
            if (amount >= 10000000)
            {
                // If the amount is greater than or equal to 1 Crore (10,000,000)
                return (amount / 10000000.0).ToString("0.##") + " Cr"; // Format in Crores
            }
            else if (amount >= 100000)
            {
                // If the amount is greater than or equal to 1 Lakh (100,000)
                return (amount / 100000.0).ToString("0.##") + " L"; // Format in Lakhs
            }
            else if (amount >= 1000)
            {
                // For amounts between 1,000 and 1,00,000, show in Lakhs with precision
                return (amount / 100000.0).ToString("0.##") + " L"; // Convert thousand values to Lakhs
            }
            else
            {
                // For amounts less than 1,000
                return amount.ToString("N0"); // No suffix, just the number with thousand separators
            }
        }
        // details table header


        // Fetch detailed product data for a branch from SQL Server
        //private DataTable GetBranchDetailData(string branchID)
        //{
        //    try
        //    {
        //        // Use the branchID to fetch detailed data for the specific branch
        //        DataSet ds = clscon.BindDetailData(branchID, "Gold");

        //        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
        //        {
        //            string branchName = ds.Tables[0].Rows[0]["location"].ToString();
        //            BranchLabel.Text = branchName;
        //            return ds.Tables[0];
        //        }
        //        else
        //        {
        //            return new DataTable();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("Error fetching branch detail data", ex);
        //    }
        //}

        //protected void goldBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable goldData = clscon.BindDetailData(branchID, "Gold").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = goldData;
        //    DetailGrid.DataBind();                                                                     // Bind the goldData to your grid
        //}

        //protected void SilverBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable silverData = clscon.BindDetailData(branchID, "Silver").Tables[0]; // Pass "Silver" as the metal name
        //    DetailGrid.DataSource = silverData;
        //    DetailGrid.DataBind();                                                                    // Bind the silverData to your grid
        //}

        //protected void DiamondBtn_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable diamondData = clscon.BindDetailData(branchID, "Diamond").Tables[0]; // Pass "Diamond" as the metal name
        //    DetailGrid.DataSource = diamondData;
        //    DetailGrid.DataBind();                                                                                // Bind the diamondData to your grid
        //}

        //// Helper method to get the branch ID (you need to implement this method)
        //private string GetBranchID()
        //{
        //    // Check if the ViewState has the branchID
        //    if (ViewState["SelectedBranchID"] != null)
        //    {
        //        return ViewState["SelectedBranchID"].ToString();
        //    }
        //    else
        //    {
        //        throw new Exception("Branch ID not set or available");
        //    }
        //}

        //protected void PlatinumBTN_Click(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable PlatinumData = clscon.BindDetailData(branchID, "Platinum").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = PlatinumData;
        //    DetailGrid.DataBind();
        //}



        //protected void RateItemBtn_Click1(object sender, EventArgs e)
        //{
        //    string branchID = GetBranchID(); // Replace with your logic to get the branch ID
        //    DataTable rateData = clscon.BindDetailData(branchID, "MRP").Tables[0]; // Pass "Gold" as the metal name
        //    DetailGrid.DataSource = rateData;
        //    DetailGrid.DataBind();
        //}

        //private void BindDetailGrid(string branchID)
        //{
        //    // Call the BindDetailData method to get the product data for the selected branch and metal
        //    DataSet detailData = clscon.BindDetailData(branchID, "Gold");

        //    // Check if the dataset contains any tables and rows
        //    if (detailData != null && detailData.Tables.Count > 0 && detailData.Tables[0].Rows.Count > 0)
        //    {
        //        // Retrieve the branch name from the first row of the dataset
        //        string branchName = detailData.Tables[0].Rows[0]["location"].ToString();

        //        // Set the label text to include the branch name
        //        BranchLabel.Text = "Details for " + branchName + " Branch: ";

        //        // Bind the data to the DetailGrid
        //        DetailGrid.DataSource = detailData;
        //        DetailGrid.DataBind();
        //    }
        //    else
        //    {
        //        // Handle the case when there is no data returned
        //        BranchLabel.Text = "No details available for the selected branch.";
        //        DetailGrid.DataSource = null;
        //        DetailGrid.DataBind();
        //    }
        //}


        // Fetch branch summary data from SQL Server with a specific location
        
    }
}