﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;

namespace PSMDashboard.AppCode
{
    public class ClsPsmDash
    {

        public SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["conSTR"].ConnectionString);
        public SqlConnection con1 = new SqlConnection(ConfigurationManager.ConnectionStrings["ConSTR"].ConnectionString);

        public SqlConnection OpenConnection()
        {

            if (con.State == ConnectionState.Closed)
            {
                if (con.ConnectionString == "")
                {
                    con = new SqlConnection(ConfigurationManager.ConnectionStrings["conSTR"].ConnectionString);
                }
                con.Open();
            }
            else
            {
                con.Close();
            }
            return con;
        }


        public SqlConnection CloseConnection()
        {
            if (con.State == ConnectionState.Open)
            {
                con.Close();
                con.Dispose();
            }
            return con;
        }

        #region Sales Summary data
        public DataSet BindSummaryData(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet summaryData = new DataSet();
            string query = @"

        location,
        SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetwt,
        SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetwt,
        SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetwt,
        SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS platNetwt,
        SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetwt
    FROM 
        SalesMaster
    WHERE 
        (@location = 'ALL' OR location = @location)  -- Filter by location, or get all locations
        AND (@fromDate IS NULL OR trandate >= @fromDate) 
        AND (@toDate IS NULL OR trandate <= @toDate)
    GROUP BY 
        location;
    ";



            try
            {
                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@location", location);  // Location filter
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);      // Handle null dates

                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);

                string values = query;
            }
         

            
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }


        #endregion

        #region Sales Detail data
        // Modify the BindDetailData method to include an additional parameter for metal
        public DataSet BindDetailData(string branchID, string metalName, DateTime? fromDate, DateTime? toDate)
        {
            DataSet detailData = new DataSet();
            string query = "";
            string vaslues = "";

            try
            {
                query +=
@"SELECT Product, 
       SUM(GrsWt) AS TotalGrsWt,
       location,
       SUM(NetWt) AS TotalNetWt
FROM SalesMaster
WHERE location = @branchID
  AND Metal = @metalName
  AND (@fromDate IS NULL OR trandate >= @fromDate)
  AND (@toDate IS NULL OR trandate <= @toDate)
GROUP BY Counter, Product, Metal, location;
";
                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@branchID", branchID);
                selectCmd.Parameters.AddWithValue("@metalName", metalName);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);      // Handle null dates


                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(detailData);

                 vaslues = query;

            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return detailData;
        }

        #endregion



        #region Order Count and  Values 


        public DataSet BindOrderSummaryDataValues(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet summaryData = new DataSet();
            string query = @"

    SELECT     Branch,
    COUNT(CASE WHEN Metal = 'Diamond' THEN 1 ELSE NULL END) AS DiamondOrderCount,
    COUNT(CASE WHEN Metal = 'Gold' THEN 1 ELSE NULL END) AS GoldOrderCount,
    COUNT(CASE WHEN Metal = 'Silver' THEN 1 ELSE NULL END) AS SilverOrderCount,
    COUNT(CASE WHEN Metal = 'Platinum' THEN 1 ELSE NULL END) AS PlatinumOrderCount,
    COUNT(CASE WHEN Metal = 'MRP' THEN 1 ELSE NULL END) AS MRPOrderCount,
    SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetWt,
    SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetWt,
    SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetWt,
    SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS PlatNetWt,
    SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetWt
FROM 
    UpdatedOrder
 WHERE 
        (@location = 'ALL' OR Branch = @location)  -- Filter by location, or get all locations
        AND (@fromDate IS NULL OR OrderDate >= @fromDate) 
        AND (@toDate IS NULL OR OrderDate <= @toDate)
GROUP BY 
    Branch;

";

            try
            {
                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }


        #endregion


       
        #region Order Summary data
        public DataSet BindOrderSummaryData(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet summaryData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT 
    Branch,
	
    SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetwt,
    SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetwt,
    SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetwt,
    SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS platNetwt,
   SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetwt
FROM 
    UpdatedOrder
 WHERE 
        (@location = 'ALL' OR Branch = @location)  -- Filter by location, or get all locations
        AND (@fromDate IS NULL OR OrderDate >= @fromDate) 
        AND (@toDate IS NULL OR OrderDate <= @toDate)
GROUP BY 
    Branch
";
                //  query += "FROM SalesMaster ";
                // query += "WHERE location = @location";  // Filter by location

                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);
                 selectCmd.Parameters.AddWithValue("@location", location);  // Use parameterized query to prevent SQL injection
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }

        #endregion


        #region Order details data
        // Modify the BindDetailData method to include an additional parameter for metal
        public DataSet BindOrderDetailData(string branchID, string metalName,DateTime? fromDate, DateTime? toDate)
        {
            DataSet detailData = new DataSet();
            string query = "";

            try


            {
                query += @"  SELECT ProName, SUM(GrossWt) AS TotalGrsWt,

   Branch,
   SUM(NetWt) AS TotalNetWt FROM UpdatedOrder WHERE Branch ='" + branchID + "'  AND  Metal ='" + metalName + "'  AND (@fromDate IS NULL OR OrderDate >= @fromDate) AND (@toDate IS NULL OR OrderDate <= @toDate)  GROUP BY  ProName, Metal, Branch; ";


                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@branchID", branchID);
                selectCmd.Parameters.AddWithValue("@metalName", metalName);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);    // Add the metal name parameter
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(detailData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return detailData;
        }

        #endregion


        #region Repair Summary data
        public DataSet BindRepairSummaryData(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet summaryData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT 
    Branch,
	
    SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetwt,
    SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetwt,
    SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetwt,
    SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS platNetwt,
   SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetwt
FROM 
    UpdatedOrder  where OrderNo like '%REP%'
 and (@location = 'ALL' OR Branch = @location)
 AND (@fromDate IS NULL OR OrderDate >= @fromDate) 
        AND (@toDate IS NULL OR OrderDate <= @toDate)

GROUP BY 
    Branch
";
                //  query += "FROM SalesMaster ";
                // query += "WHERE location = @location";  // Filter by location

                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@location", location); 
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);// Use parameterized query to prevent SQL injection
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }

        #endregion

        #region Old Ornament Summary data
        public DataSet BindOldOrnamnetsData(string location)
        {
            DataSet summaryData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT 
    location,
    SUM(CASE WHEN Metal = 'Diamond' THEN NetWt ELSE 0 END) AS DiaNetwt,
    SUM(CASE WHEN Metal = 'Gold' THEN NetWt ELSE 0 END) AS GoldNetwt,
    SUM(CASE WHEN Metal = 'Silver' THEN NetWt ELSE 0 END) AS SilverNetwt,
    SUM(CASE WHEN Metal = 'Platinum' THEN NetWt ELSE 0 END) AS platNetwt,
    SUM(CASE WHEN Metal = 'MRP' THEN NetWt ELSE 0 END) AS MRPNetwt
FROM 
    StockMaster
GROUP BY 
    location;
";
                //  query += "FROM SalesMaster ";
                // query += "WHERE location = @location";  // Filter by location

                SqlCommand selectCmd = new SqlCommand(query, con);
                // selectCmd.Parameters.AddWithValue("@location", location);  // Use parameterized query to prevent SQL injection
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }

        #endregion

  


        #region Order details
        // Modify the BindDetailData method to include an additional parameter for metal
        public DataSet BindRepairDetailData(string branchID, string metalName ,DateTime? fromDate, DateTime? toDate)
        {
            DataSet detailData = new DataSet();
            string query = "";

            try


            {
                query += @"  SELECT ProName, SUM(GrossWt) AS TotalGrsWt,

   Branch,
   SUM(NetWt) AS TotalNetWt FROM UpdatedOrder WHERE Branch ='" + branchID + "'  AND  Metal ='" + metalName + "'  AND (@fromDate IS NULL OR OrderDate >= @fromDate) AND (@toDate IS NULL OR OrderDate <= @toDate) and OrderNo like '%REP%' GROUP BY  ProName, Metal, Branch; ";


                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@branchID", branchID);
                selectCmd.Parameters.AddWithValue("@metalName", metalName);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);  // Handle null dates
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);
                // Add the metal name parameter
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(detailData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return detailData;
        }

        #endregion



        #region dateadded chit
        public DataSet BindChitDetailsda(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet chitDetails = new DataSet();

            // Ensure location is not null or empty
            location = string.IsNullOrEmpty(location) ? "ALL" : location;

            string query = @"SELECT 
        location,
        COUNT(CASE WHEN GroupCode='SCV' THEN 1 ELSE NULL END) AS NewSwarnaSchemeCount,
        COUNT(CASE WHEN GroupCode='CV' THEN 1 ELSE NULL END) AS SwarnaSchemeCount,
        SUM(CASE WHEN GroupCode='SCV' THEN ReceiptAmount ELSE 0 END) AS TotalNewSwarnaValue,
        SUM(CASE WHEN GroupCode='CV' THEN ReceiptAmount ELSE 0 END) AS TotalSwarnaValue
    FROM 
        scheme
    WHERE 
Collection_New='New' and
        (@location = 'ALL' OR location = @location) AND
        (@fromDate IS NULL OR DateOfJoin >= @fromDate) AND
        (@toDate IS NULL OR DateOfJoin <= @toDate)
    GROUP BY 
        location;";

            try
            {
                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@location", location);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);

                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(chitDetails);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return chitDetails;
        }


        #endregion



        #region dateadded chit
        public DataSet BindNewChitDetailsda(string location, DateTime? fromDate, DateTime? toDate)
        {
            DataSet chitDetails = new DataSet();

            // Ensure location is not null or empty
            location = string.IsNullOrEmpty(location) ? "ALL" : location;

            string query = @"SELECT 
        location,
        COUNT(CASE WHEN GroupCode='SCV' THEN 1 ELSE NULL END) AS NewSwarnaSchemeCount,
        COUNT(CASE WHEN GroupCode='CV' THEN 1 ELSE NULL END) AS SwarnaSchemeCount,
        SUM(CASE WHEN GroupCode='SCV' THEN ReceiptAmount ELSE 0 END) AS TotalNewSwarnaValue,
        SUM(CASE WHEN GroupCode='CV' THEN ReceiptAmount ELSE 0 END) AS TotalSwarnaValue
    FROM 
        scheme
    WHERE 
Collection_New='New' and
        (@location = 'ALL' OR location = @location) AND
        (@fromDate IS NULL OR DateOfJoin >= @fromDate) AND
        (@toDate IS NULL OR DateOfJoin <= @toDate)
    GROUP BY 
        location;";

            try
            {
                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@location", location);
                selectCmd.Parameters.AddWithValue("@fromDate", (object)fromDate ?? DBNull.Value);
                selectCmd.Parameters.AddWithValue("@toDate", (object)toDate ?? DBNull.Value);

                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(chitDetails);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return chitDetails;
        }


        #endregion

        #region old oranaments brancg details
        // Modify the BindDetailData method to include an additional parameter for metal
        public DataSet BindOldDetailData(string branchID, string metalName)
        {
            DataSet detailData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT Product,SUM(GrsWt) AS TotalGrsWt,
   
   location,
    SUM(NetWt) AS TotalNetWt FROM StockMaster WHERE location =@branchID  AND  Metal ='" + metalName + "' GROUP BY Counter, Product, Metal,location; ";


                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@branchID", branchID);
                selectCmd.Parameters.AddWithValue("@metalName", metalName); // Add the metal name parameter
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(detailData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return detailData;
        }

        #endregion

        #region Chit Enroll data
        public DataSet BindChitDetails(string location)
        {
            DataSet summaryData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT 
    location,
    -- Separate scheme counts
    COUNT(CASE WHEN GroupCode='SCV' THEN 1 ELSE NULL END) AS NewSwarnaSchemeCount,
    COUNT(CASE WHEN GroupCode='CV' THEN 1 ELSE NULL END) AS SwarnaSchemeCount,
    -- Separate amounts and pending amounts

    -- Total values for each scheme
    SUM(CASE WHEN GroupCode='SCV' THEN ReceiptAmount ELSE 0 END) AS TotalNewSwarnaValue,
    SUM(CASE WHEN GroupCode='CV' THEN ReceiptAmount ELSE 0 END) AS TotalSwarnaValue
FROM 
    scheme
GROUP BY 
    location;
";
                //  query += "FROM SalesMaster ";
                // query += "WHERE location = @location";  // Filter by location

                SqlCommand selectCmd = new SqlCommand(query, con);
                // selectCmd.Parameters.AddWithValue("@location", location);  // Use parameterized query to prevent SQL injection
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(summaryData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return summaryData;
        }

        #endregion
        
       

        #region
        // Modify the BindDetailData method to include an additional parameter for metal
    //    public DataSet BindOrderDetailData(string branchID, string metalName)
    //    {
    //        DataSet detailData = new DataSet();
    //        string query = "";
         
    //        try
    //        {
    //            query += @"SELECT ProName, SUM(GrossWt) AS TotalGrsWt,
    //        Branch,
    //SUM(NetWt) AS TotalNetWt FROM UpdatedOrder WHERE Branch =@branchID  AND  Metal ='" + metalName + "' GROUP BY ProName, Metal,Branch ";


    //            SqlCommand selectCmd = new SqlCommand(query, con);
    //            selectCmd.Parameters.AddWithValue("@branchID", branchID);
    //            selectCmd.Parameters.AddWithValue("@metalName", metalName); // Add the metal name parameter
    //            SqlDataAdapter da = new SqlDataAdapter(selectCmd);
    //            da.Fill(detailData);
    //        }
    //        catch (Exception ex)
    //        {
    //            CloseConnection();
    //            throw ex;
    //        }

    //        return detailData;
    //    }

        #endregion
        #region Sales Detail data
        // Modify the BindDetailData method to include an additional parameter for metal
        public DataSet BindDetailDataold(string branchID, string metalName)
        {
            DataSet detailData = new DataSet();
            string query = "";

            try
            {
                query += @"SELECT Product,SUM(GrsWt) AS TotalGrsWt,
   
   location,
    SUM(NetWt) AS TotalNetWt FROM SalesMaster WHERE location =@branchID  AND  Metal ='" + metalName+ "' GROUP BY Counter, Product, Metal,location; ";
              

                SqlCommand selectCmd = new SqlCommand(query, con);
                selectCmd.Parameters.AddWithValue("@branchID", branchID);
                selectCmd.Parameters.AddWithValue("@metalName", metalName); // Add the metal name parameter
                SqlDataAdapter da = new SqlDataAdapter(selectCmd);
                da.Fill(detailData);
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }

            return detailData;
        }

        #endregion

        #region StockLogin

        public DataSet StockLogin(String varEmployeeId, String varPassword)
        {

            DataSet LoginDs = new DataSet();
            String strQ = "";
            try
            {

                strQ = "select EmpID,Password,EmpName from usertbl where EmpID = '" + varEmployeeId + "' and Password='" + varPassword + "'";
                SqlCommand selectCmd = new SqlCommand(strQ, con);
                SqlDataAdapter DA = new SqlDataAdapter();
                DA.SelectCommand = selectCmd;
                DA.Fill(LoginDs);

                return LoginDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
     
            }
        }
        #endregion

        //non coversation block

        #region  StockNoc
        public DataSet StockNoc(String customerName, String customerPhone)
        {

            DataSet NocDs = new DataSet();
            String strQ = "";
            try
            {
                strQ = "insert into NocDB (CustomerName, CustomerPhone) values ('" + customerName + "','" + customerPhone + "')";
                SqlCommand selectCmd = new SqlCommand(strQ, con);
                SqlDataAdapter DA = new SqlDataAdapter();
                DA.SelectCommand = selectCmd;
                DA.Fill(NocDs);

                return NocDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }
        }

        #endregion

        #region  StocReq


        //dsStockReq = clsCon.StockReq(proID, pro, SubProduct, Size, Weight, ReqPcs, TotalWeight);
        public DataSet StockReq(int proID, String pro, int subProID, String subPro, String size, String weight, String reqPcs, String tolWeight)
        {

            DataSet StockReqDs = new DataSet();
            String strQ = "";
            try
            {
                //'" + product + "',
                strQ = "insert into StockReq_DB (ProductID,Product,SubProductID,SubProduct,Size,Weight,ReqPcs,TotalWeight) values ('" + proID + "','" + pro + "','" + subProID + "','" + subPro + "','" + size + "','" + weight + "','" + reqPcs + "','" + tolWeight + "')";
                SqlCommand selectCmd = new SqlCommand(strQ, con);
                SqlDataAdapter DA = new SqlDataAdapter();
                DA.SelectCommand = selectCmd;
                DA.Fill(StockReqDs);

                return StockReqDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }
        }

        #endregion


        #region StockReq
        public DataSet StockReq()
        {
            DataSet StockReqDs = new DataSet();
            string strQ = "SELECT ProductID, ProductName, MetalID, Metal FROM Product_DB"; // Only select ProductID and ProductName

            try
            {
                // Initialize the command with the query and connection
                SqlCommand selectCmd = new SqlCommand(strQ, con);

                // Execute the command and fill the DataSet
                SqlDataAdapter DA = new SqlDataAdapter(selectCmd);
                DA.Fill(StockReqDs);

                return StockReqDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }
        }
        #endregion
        public DataSet WalkIN()
        {
            DataSet StockReqDs = new DataSet();
            string strQ = "SELECT ProductID, ProductName, MetalID, Metal FROM Product_DB"; // Only select ProductID and ProductName

            try
            {
                // Initialize the command with the query and connection
                SqlCommand selectCmd = new SqlCommand(strQ, con);

                // Execute the command and fill the DataSet
                SqlDataAdapter DA = new SqlDataAdapter(selectCmd);
                DA.Fill(StockReqDs);

                return StockReqDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }
        }
        public ProductDetails GetProductDetails(string productName)
        {
            ProductDetails productDetails = null;

            // Define the SQL query to get product details by name
            string query = "SELECT Size, Weight, Metal FROM Products WHERE ProductName = @ProductName";

          
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add the parameter to prevent SQL injection
                    command.Parameters.AddWithValue("@ProductName", productName);

                    // Open the connection
                    con.Open();

                    // Execute the query and retrieve the data
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            // Read the first row (you may need to handle multiple rows)
                            reader.Read();

                            // Populate the ProductDetails object
                            productDetails = new ProductDetails
                            {
                                Size = reader["Size"].ToString(),
                                Weight = reader["Weight"].ToString(),
                                metal = reader["Metal"].ToString() // Assuming "Metal" field is present
                            };
                        }
                    }
                }
            

            return productDetails; // Return the product details (null if not found)
        }
        #region  StocReq
        public DataSet WalkReq(int proID, String pro, String metal, int metalID, int count)
        {

            DataSet StockReqDs = new DataSet();
            String strQ = "";
            try
            {
                //'" + product + "',
                strQ = "insert into WalkIN_DB (ProductID,ProductName,metalID,Metal,CusCount) values ('" + proID + "','" + pro + "','" + metalID + "','" + metal + "','" + count + "')";
                SqlCommand selectCmd = new SqlCommand(strQ, con);
                SqlDataAdapter DA = new SqlDataAdapter();
                DA.SelectCommand = selectCmd;
                DA.Fill(StockReqDs);

                return StockReqDs;
            }
            catch (Exception ex)
            {
                CloseConnection();
                throw ex;
            }
        }

        #endregion

     
        // Method to get product names for AutoComplete
        public List<string> GetProductNames(string prefixText)
        {
            List<string> productNames = new List<string>();
        
                string query = "SELECT Product FROM ProductMaster WHERE Product LIKE @prefixText + '%'";
                SqlCommand command = new SqlCommand(query, con);
                command.Parameters.AddWithValue("@prefixText", prefixText);
                con.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    productNames.Add(reader["Product"].ToString());
                }
           
            return productNames;
        }

        // Method to save stock requirements into the database
        public void SaveStockRequirements(List<ProductDetail> productDetailsList)
        {
          
                con.Open();
                foreach (var product in productDetailsList)
                {
                    string query = "INSERT INTO StockReq_DB (Metal, Product, Size, Weight, ReqPcs, TotalWeight) " +
                                   "VALUES (@MetalType, @Product, @Size, @Weight, @ReqPcs, @TotalWeight)";
                    using (SqlCommand command = new SqlCommand(query, con))
                    {
                        command.Parameters.AddWithValue("@MetalType", product.MetalType);
                        command.Parameters.AddWithValue("@Product", product.ProductName);
                        command.Parameters.AddWithValue("@Size", product.Size);
                        command.Parameters.AddWithValue("@Weight", product.Weight);
                        command.Parameters.AddWithValue("@ReqPcs", product.Quantity);
                        command.Parameters.AddWithValue("@TotalWeight", product.TotalWeight);

                        command.ExecuteNonQuery();
                    }
                }
            
        }

        // Optional: Method to handle any other queries you may need (e.g., for binding a dropdown)
     
    }

    // Class to represent product details (same as before)
    public class ProductDetails
    {
        public string Size { get; set; }
        public string Weight { get; set; }
        public string metal { get; set; }
    }

    // Class to represent product detail (same as before)
    public class ProductDetail
    {
        public string MetalType { get; set; }
        public string ProductName { get; set; }
        public decimal Size { get; set; }
        public decimal Weight { get; set; }
        public int Quantity { get; set; }
        public decimal TotalWeight { get; set; }
    }
}
   